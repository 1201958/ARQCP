#ifndef ASM_H
#define ASM_H

int get_n_element(int* buffer, int length, int* tail, int* head);

#endif